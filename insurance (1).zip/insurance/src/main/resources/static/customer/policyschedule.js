// Sample JSON data
var customerId = localStorage.getItem('customerId');

$.ajax({
	url: `/customer/policySchedule/${customerId}`,
	method: "GET",
	success: function(data) {
		console.log(data);
		// Define the Handlebars template
	

	
		// Function to filter and display cards based on the search input
		function filterCards(searchText) {
			const $cardContainer = $('#card-container');
			$cardContainer.empty(); // Clear previous cards

			data.forEach(item => {
				if (item.iplcDate.toLowerCase().includes(searchText.toLowerCase()) || item.description.toLowerCase().includes(searchText.toLowerCase())) {
		
					const cardItem = `
    		<div class="card">
        	<p><b>PolicyDueDate</b> : ${item.iplcDate} <br><br>  <b>PolicyPremiumAmount</b> : ${item.iplcPremium}</p>
    		</div>
			`;
					$cardContainer.append(cardItem);
				}
			});
		}

		// Initial display of all cards
		filterCards("");

		// Add an event listener to the search input
		$('#search-input').on('input', function() {
			const searchText = $(this).val();
			filterCards(searchText);
		});
	}
});


