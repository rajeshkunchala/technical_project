$(document).ready(function () {
    $("#forgotPasswordForm").submit(function (event) {
        event.preventDefault();

        // Get the entered email address
        var email = $("#email").val();

        // Simulate sending a reset link (replace this with your actual logic)
        // In this example, we'll just display a message
        var resetMessage = $("#resetMessage");
        resetMessage.html(`Reset link sent to the <b>${email}</b>`);
    });
});
