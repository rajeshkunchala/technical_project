$(document).ready(function () {
    // Handle form submission
    $("#loginForm").submit(function (event) {
        event.preventDefault();

        // Get the values of username and password
        var username = $("#username").val();
        var password = $("#password").val();


		localStorage.setItem("userEmail",username);
        // Perform an AJAX POST request to your server for authentication
        $.ajax({
            type: "POST",
            url: "/customer/UserLogin", // Replace with your server endpoint
            data: {
                username: username,
                password: password
            },
            success: 
            function (response) {
				console.log(response);
                // Assuming the server returns a success status, you can redirect to home.html
                if (response==1) {
                    window.location.href = "otp.html";
                } else {
                    // Handle authentication failure (e.g., display an error message)
                    alert("Authentication failed. Please check your credentials.");
                }
            },
            error: function (error) {
                // Handle AJAX request error
                console.error("AJAX Error: " + JSON.stringify(error));
            }
        });
    });
});