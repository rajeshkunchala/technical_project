package com.insurance.insuranceCompany.model;

import java.sql.Date;

public class Claim {
	 int clamId;
	 String clamSource;
	 String clamType;
	 Date clamDate;
	 double clamAmountRequested;
	 int clamIplcId;
	 double clamProcessedAmount;
	 Date clamProcessedDate;
	 int clamProcessedBy;
	 String clamRemarks;
	 String clamStatus;
	 String payStatus;
	 String hospName;

	public int getClamId() {
		return clamId;
	}

	public void setClamId(int clamId) {
		this.clamId = clamId;
	}

	public String getClamSource() {
		return clamSource;
	}

	public void setClamSource(String clamSource) {
		this.clamSource = clamSource;
	}

	public String getClamType() {
		return clamType;
	}

	public void setClamType(String clamType) {
		this.clamType = clamType;
	}

	public Date getClamDate() {
		return clamDate;
	}

	public void setClamDate(Date clamDate) {
		this.clamDate = clamDate;
	}

	public double getClamAmountRequested() {
		return clamAmountRequested;
	}

	public void setClamAmountRequested(double clamAmountRequested) {
		this.clamAmountRequested = clamAmountRequested;
	}

	public int getClamIplcId() {
		return clamIplcId;
	}

	public void setClamIplcId(int clamIplcId) {
		this.clamIplcId = clamIplcId;
	}

	public double getClamProcessedAmount() {
		return clamProcessedAmount;
	}

	public void setClamProcessedAmount(double clamProcessedAmount) {
		this.clamProcessedAmount = clamProcessedAmount;
	}

	public Date getClamProcessedDate() {
		return clamProcessedDate;
	}

	public void setClamProcessedDate(Date clamProcessedDate) {
		this.clamProcessedDate = clamProcessedDate;
	}

	public int getClamProcessedBy() {
		return clamProcessedBy;
	}

	public void setClamProcessedBy(int clamProcessedBy) {
		this.clamProcessedBy = clamProcessedBy;
	}

	public String getClamRemarks() {
		return clamRemarks;
	}

	public void setClamRemarks(String clamRemarks) {
		this.clamRemarks = clamRemarks;
	}

	public String getClamStatus() {
		return clamStatus;
	}

	public void setClamStatus(String clamStatus) {
		this.clamStatus = clamStatus;
	}

	public String getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}

	public String getHospName() {
		return hospName;
	}

	public void setHospName(String hospName) {
		this.hospName = hospName;
	}

	public Claim() {
		super();
	}

	@Override
	public String toString() {
		return "Claim [clamId=" + clamId + ", clamSource=" + clamSource + ", clamType=" + clamType + ", clamDate="
				+ clamDate + ", clamAmountRequested=" + clamAmountRequested + ", clamIplcId=" + clamIplcId
				+ ", clamProcessedAmount=" + clamProcessedAmount + ", clamProcessedDate=" + clamProcessedDate
				+ ", clamProcessedBy=" + clamProcessedBy + ", clamRemarks=" + clamRemarks + ", clamStatus=" + clamStatus
				+ ", payStatus=" + payStatus + ", hospName=" + hospName + "]";
	}

}