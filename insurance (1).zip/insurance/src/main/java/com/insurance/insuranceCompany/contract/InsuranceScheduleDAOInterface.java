package com.insurance.insuranceCompany.contract;

import java.util.List;

import com.insurance.insuranceCompany.model.InsurancePolicy;
import com.insurance.insuranceCompany.model.InsurancePolicySchedule;

public interface InsuranceScheduleDAOInterface {
	List<InsurancePolicySchedule> getAllSchedule();

	List<InsurancePolicySchedule> getAllScheduleById(int id);

	int getNonPaymentStatus(int id);

	List<Integer> findDistinctIplcIds();

	List<InsurancePolicy> getAllPolicies();

	int updateStatus(InsurancePolicy e);
}
