package com.insurance.insuranceCompany.controller;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.insurance.insuranceCompany.model.Disease;
import com.insurance.insuranceCompany.model.InsurancePackage;
import com.insurance.insuranceCompany.repository.PackagesRepository;

@Controller
@RequestMapping("/insurance")
public class PackagesController {
	
	@Autowired
	private PackagesRepository pr;
	private static final Logger logger = LoggerFactory.getLogger(PackagesController.class);

	
	@GetMapping("/packages")
	public String getAllPackages(Model model) {
	    try {
	        logger.trace("Entering getAllPackages method");

	        model.addAttribute("packages", pr.getAllPackages());
	        model.addAttribute("insurancePackage", new InsurancePackage());

	        logger.info("Retrieved all packages successfully.");
	        return "packages";
	    } catch (Exception e) {
	        logger.error("An error occurred in getAllPackages", e);
	        return "packages"; // Return the "packages" page even if there's an error (you can handle it differently)
	    } finally {
	        logger.trace("Exiting getAllPackages method");
	    }
	}

	
	@PostMapping("/addpackage")
	public String addhospital(Model model, @ModelAttribute("insurancePackage") InsurancePackage insp) {
	    try {
	        logger.trace("Entering addhospital method");

	        int x = pr.addPackage(insp);
	        model.addAttribute("packages", pr.getAllPackages());
	        model.addAttribute("insurancePackage", new InsurancePackage());

	        if (x == 1) {
	            model.addAttribute("msg", "Hospital added successfully");
	        } else {
	            model.addAttribute("msg", "Error occurred while adding hospital");
	        }

	        logger.info("Hospital added successfully.");
	        return "packages";
	    } catch (Exception e) {
	        logger.error("An error occurred in addhospital", e);
	        return "packages"; // Return the "packages" page even if there's an error (you can handle it differently)
	    } finally {
	        logger.trace("Exiting addhospital method");
	    }
	}

	
	@PostMapping(value = "/deletePackage")
	@ResponseBody
	public String deleteHospital(@ModelAttribute("packageId") String pid) {
	    logger.trace("Entering deleteHospital method");

	    try {
	        int x = pr.deletePackage(Integer.parseInt(pid));

	        if (x == 1) {
	            logger.info("Package deleted successfully.");
	            return "Package deleted successfully...!";
	        } else {
	            logger.error("Error occurred while deleting package.");
	            return "Error occurred";
	        }
	    } catch (Exception e) {
	        logger.error("An error occurred in deleteHospital", e);
	        return "An error occurred";
	    } finally {
	        logger.trace("Exiting deleteHospital method");
	    }
	}

	@GetMapping(value = "/showDiseases")
	public String showDiseases(@ModelAttribute("packageId") String pid, Model model) {
	    // Log a message indicating the received packageId
	    logger.info("Received packageId: {}", pid);

	    try {
	        // Retrieve the list of diseases
	        ArrayList<Disease> x = pr.showDiseases(Integer.parseInt(pid));

	        // Add the list of diseases to the model
	        model.addAttribute("diseaseslist", x);

	        // Return the view name
	        return "diseases";
	    } catch (Exception e) {
	        // Log an error message for other exceptions
	        logger.error("An error occurred in showDiseases", e);

	        // Handle the error appropriately, e.g., return an error page
	        return "diseases";
	    }
	}

}
