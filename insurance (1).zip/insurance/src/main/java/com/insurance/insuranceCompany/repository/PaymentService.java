package com.insurance.insuranceCompany.repository;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.insuranceCompany.contract.PaymentContract;
import com.insurance.insuranceCompany.model.PaymentModel;

@Service
public class PaymentService  {
	@Autowired
	PaymentContract pc;

	public ArrayList<PaymentModel> getAllTransaction() {
		return pc.getAllTransaction();
	}
}
