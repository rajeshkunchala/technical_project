package com.insurance.insuranceCompany.contract;

import com.insurance.insuranceCompany.model.Login;

public interface LoginContract {
	public Login checkCredentials(Login lc);

	public int resetpwd(String email, String pwd);

	public int checkMail(String email);

	public int checkAccess(int lc, String string);
}
