package com.insurance.insuranceCompany.UserDefinedExceptioHandler;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class RequestedAmountExceptionHandler {

@ExceptionHandler(RequestedAmountException.class)
public String handlePolicyIDException(RequestedAmountException ex,Model model) {
	String errorCode = ex.getErrorCode();
	String message = ex.getMsg();
    model.addAttribute("errorCode", errorCode);
    model.addAttribute("errorMessage", message);

    return "errorPage"; 
   
}
}