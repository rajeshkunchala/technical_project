package com.insurance.insuranceCompany.controller;

import java.util.ArrayList;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.insurance.insuranceCompany.model.InsurancePackage;
import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.model.NetworkHospitals;
import com.insurance.insuranceCompany.repository.NetworkHospitalRepository;
import com.insurance.insuranceCompany.service.NetworkHospitalService;

@Controller
@RequestMapping("/insurance")
public class NetworkHospitalController {

    @Autowired
    private NetworkHospitalRepository nr;
    
    @Autowired
    HttpSession session;
    
    @Autowired
    NetworkHospitalService nhs;

    // to retrieve all hospitals
    @GetMapping(value = "/hospitals")
    public String getAllHospitals(HttpServletRequest request, Model model) {
        Object lc = session.getAttribute("login");
        if (lc == null || (int) lc == 0) {
            model.addAttribute("noaccess", "you need to login first");
            model.addAttribute("login", new Login());
            return "loginPage";
        }
        int hospitalCount = nhs.getAllHospitals().size();
        model.addAttribute("networkHospital", new NetworkHospitals());
        model.addAttribute("hospitals", nhs.getAllHospitals());
        model.addAttribute("hospitalCount", hospitalCount);
        return "networkHospitals";
    }

    // to add a hospital
    @PostMapping("/addhospital")
    @ResponseBody
    public String addHospital(Model model, @RequestBody NetworkHospitals netHsp) {
        if (nr.addHospital(netHsp) == 1)
            return "hospital added successfully";
        else
            return "error occurred while adding hospital";
    }

    //  to edit a hospital
    @PostMapping("/editHospital")
    public String editHospital(Model model, @ModelAttribute("networkHospital") NetworkHospitals netHsp) {
        model.addAttribute("networkHospital", new NetworkHospitals());
        model.addAttribute("hospitals", nhs.getAllHospitals());
        if (nhs.editHospital(netHsp) == 1)
            model.addAttribute("msg", "hospital updated successfully");
        else
            model.addAttribute("msg", "error occurred while updating hospital");
        return "networkHospitals";
    }

    //to delete a hospital
    @PostMapping(value = "/deleteHospital")
    @ResponseBody
    public String deleteHospital(@ModelAttribute("hospitalId") String hid) {
        if (nr.deleteHospital(Integer.parseInt(hid)) == 1)
            return "hospital deleted successfully...!";
        return "error occurred";
    }

    //to get related packages for a hospital
    @GetMapping("/getPackages")
    public String getPackages(@RequestParam(name = "hspid") int hspid, Model model) {
        model.addAttribute("hospid", hspid);
        ArrayList<InsurancePackage> ip = nhs.getRelatedPackages(hspid);
        model.addAttribute("packages", ip);
        return "hptlRelatedPack";
    }

    // to add an insurance package
    @PostMapping("/addPackage")
    @ResponseBody
    public String addInsurancePackage(@RequestParam String title, @RequestParam String desc,
            @RequestParam String status, @RequestParam long rangeStart, @RequestParam long rangeEnd,
            @RequestParam Integer ageLimitStart, @RequestParam Integer ageLimitEnd, @RequestParam String hospid) {
        int message = nr.addPackage(title, desc, status, rangeStart, rangeEnd, ageLimitStart, ageLimitEnd,
                Integer.parseInt(hospid));

        if (message == 1)
            return "record added successfully";
        else
            return "error occurred while adding record";
    }

    // to delete an insurance package
    @PostMapping("/deletePackages")
    @ResponseBody
    public String deletePackages(@RequestParam String did, String hospid) {
        int message = nr.deletePackage(Integer.parseInt(did), Integer.parseInt(hospid));
        if (message == 1)
            return "record deleted successfully";
        else
            return "error occurred while deleting record";
    }

    //  to edit an insurance package
    @PostMapping("/editPackage")
    @ResponseBody
    public String editPackage(@RequestParam String Id, String title, String Description, String status,
            String rangeStart, String rangeEnd, String ageLimitStrt, String ageLimitEnd, Model model) {
        String message = nr.editPackage(Id, title, Description, status, rangeStart, rangeEnd, ageLimitStrt,
                ageLimitEnd);
        return message;
    }

    // to search for hospitals by name
    @GetMapping("/searchbyname")
    public String search(@ModelAttribute("search") String search, Model model) {
        int hospitalCount = nhs.getAllHospitals().size();
        model.addAttribute("networkHospital", new NetworkHospitals());
        model.addAttribute("hospitals", nhs.getSearchHospitals(search));
        model.addAttribute("hospitalCount", hospitalCount);
        return "networkHospitals";
    }
}
