package com.insurance.insuranceCompany.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.insurance.insuranceCompany.contract.DiseaseDAOInterface;
import com.insurance.insuranceCompany.contract.DiseaseRepositoryInterface;

@Repository
public class DiseaseRepositoryImpl implements DiseaseRepositoryInterface {
	@Autowired
	DiseaseDAOInterface ddi;

	@Override
	public String addDisease(String name, String iscCode, String desc, String status) {
		return ddi.addDisease(name, iscCode, desc, status);
	}

	@Override
	public String editDisease(String name, String ICDCode, String desc, String status) {
		return ddi.editDisease(name, ICDCode, desc, status);
	}

	@Override
	public String deleteDisease(String name) {
		return ddi.deleteDisease(name);
	}

}
