package com.insurance.insuranceCompany.Dao;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.insurance.insuranceCompany.contract.PaymentContract;
import com.insurance.insuranceCompany.model.PaymentModel;
import com.insurance.insuranceCompany.rowMapper.PaymentRowMapper;

@Component
public class PaymentDAO implements PaymentContract {
	@Autowired
	JdbcTemplate jdbc;

	@Override
	public ArrayList<PaymentModel> getAllTransaction() {
		String Sql = "select * from InsurancePolicyPayments";
		return (ArrayList<PaymentModel>) jdbc.query(Sql, new PaymentRowMapper());
	}
}
