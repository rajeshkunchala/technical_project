package com.insurance.Customeroptions.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.insurance.Customeroptions.contracts.InterfaceInsurancePackageAndPolicyRepository;
import com.insurance.Customeroptions.model.Faq;
import com.insurance.Customeroptions.model.FormData;
import com.insurance.Customeroptions.model.InsurancePackages;
import com.insurance.Customeroptions.model.InsurancePolicy;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/customer")
public class CustomerOptionsController {

	private static final Logger logger = LoggerFactory.getLogger(CustomerOptionsController.class);

	@Autowired(required = true)
	InterfaceInsurancePackageAndPolicyRepository irrp;

	@Autowired
	HttpSession session;

	// Get all insurance policies
	@GetMapping(value = "/getAllInsurancePolicies")
	public List<InsurancePolicy> getAllInsurancePolicies(Model model) {
		try {
			List<InsurancePolicy> li = irrp.getAllInsurancePolicies();
			model.addAttribute("list", li);
			logger.info("Retrieved all insurance policies successfully");
			return li;
		} catch (Exception e) {
			logger.error("Error occurred while retrieving all insurance policies", e);
			throw e; // rethrow the exception
		}
	}

	// Get insurance policies for a specific customer
	@GetMapping("/getCustomersInsurancePolicy/{customerId}")
	@ResponseBody
	public List<InsurancePolicy> getCustomerInsurancePolicy(Model model, @PathVariable Integer customerId) {
		try {
			List<InsurancePolicy> li = irrp.getCustomerInsurancePolicy(customerId);
			model.addAttribute("list", li);
			logger.info("Retrieved insurance policies for customer ID: " + customerId + " successfully");
			return li;
		} catch (Exception e) {
			logger.error("Error occurred while retrieving insurance policies for customer ID: " + customerId, e);
			throw e; // rethrow the exception
		}
	}

	// Get all FAQs
	@GetMapping(value = "/getFAQS")
	public List<Faq> getAllFAQS(Model model) {
		try {
			List<Faq> li = irrp.getAllFAQS();
			model.addAttribute("list", li);
			logger.info("Retrieved all FAQs successfully");
			return li;
		} catch (Exception e) {
			logger.error("Error occurred while retrieving all FAQs", e);
			throw e; // rethrow the exception
		}
	}

	// Get general FAQs
	@GetMapping(value = "/getGeneralFAQS")
	public List<Faq> getGeneralFAQS(Model model) {
		try {
			List<Faq> li = irrp.getGeneralFAQS();
			model.addAttribute("list", li);
			logger.info("Retrieved general FAQs successfully");
			return li;
		} catch (Exception e) {
			logger.error("Error occurred while retrieving general FAQs", e);
			throw e; // rethrow the exception
		}
	}

	// Get coverage and benefits FAQs
	@GetMapping(value = "/getCoverageandBenefitsFAQS")
	public List<Faq> getCoverageandBenefitsFAQS(Model model) {
		try {
			List<Faq> li = irrp.getCoverageandBenefitsFAQS();
			model.addAttribute("list", li);
			logger.info("Retrieved coverage and benefits FAQs successfully");
			return li;
		} catch (Exception e) {
			logger.error("Error occurred while retrieving coverage and benefits FAQs", e);
			throw e; // rethrow the exception
		}
	}

	// Get all insurance packages
	@GetMapping(value = "/getInsurancePackages")
	public List<InsurancePackages> getInsurancePackages(Model model) {
		try {
			List<InsurancePackages> li = irrp.getInsurancePackages();
			model.addAttribute("list", li);
			logger.info("Retrieved all insurance packages successfully");
			return li;
		} catch (Exception e) {
			logger.error("Error occurred while retrieving all insurance packages", e);
			throw e; // rethrow the exception
		}
	}

	// Create a new customer and add to the database
	@RequestMapping(value = "/applyInsurance", method = RequestMethod.POST)
	public ResponseEntity<Object> createBook(@RequestBody FormData loan) {
		try {
			logger.info("Received new customer data: " + loan.toString());
			Long custId = irrp.addCustomer(loan);

			logger.info("Customer added successfully");

			return new ResponseEntity<>(custId, HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error occurred while adding customer", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add customer");
		}
	}
}