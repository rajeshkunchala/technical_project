package com.insurance.Customeroptions.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.insurance.Customeroptions.model.Faq;
import com.insurance.Customeroptions.model.FormData;
import com.insurance.Customeroptions.model.InsurancePackages;
import com.insurance.Customeroptions.model.InsurancePolicy;
import com.insurance.Customeroptions.rowmapper.FaqRowMapper;
import com.insurance.Customeroptions.rowmapper.InsurancePackagesRowMapper;
import com.insurance.Customeroptions.rowmapper.InsurancePolicyMapper;
import com.insurance.Customeroptions.contracts.*;

import jakarta.servlet.http.HttpSession;

@Component
public class InterfaceInsurancePolicyandPackageDAOImpl implements InterfaceInsurancePolicyandPackageDAO {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    HttpSession session;

    private String SQL_GET_INSURANCEPOLICIES = "SELECT * FROM insurancepolicies1";
    private String SQL_GET_CUSTID_INSURANCEPOLICY = "SELECT * FROM insurancepolicies1 ";
    private String SQL_GET_FAQS = "SELECT * FROM HealthInsuranceFAQs";
    private String SQL_GET_GFAQS = "SELECT * FROM HealthInsuranceFAQs WHERE category='General'";
    private String SQL_GET_CBFAQS = "SELECT * FROM HealthInsuranceFAQs WHERE category='Coverage and Benefits'";
    private String SQL_GET_INSURANCEPACKAGES = "SELECT * FROM InsurancePackages";

    @Override
    public List<InsurancePolicy> getAllInsurancePolicies() {
        return jdbcTemplate.query(SQL_GET_INSURANCEPOLICIES, new InsurancePolicyMapper());
    }

    @Override
    public List<Faq> getAllFAQS() {
        return jdbcTemplate.query(SQL_GET_FAQS, new FaqRowMapper());
    }

    @Override
    public List<InsurancePolicy> getCustomerInsurancePolicy(int cust) {
        return jdbcTemplate.query(SQL_GET_CUSTID_INSURANCEPOLICY, new Object[] { cust }, new InsurancePolicyMapper());
    }

    @Override
    public List<InsurancePackages> getInsurancePackages() {
        return jdbcTemplate.query(SQL_GET_INSURANCEPACKAGES, new InsurancePackagesRowMapper());
    }

    @Override
    public Long addCustomer(FormData formData) {
    	Long CID = (long) 0;
        try {
            // Extract Aadhar number from form data
            long aadharLong = 0;
            try {
                String aadharString = formData.getAadhar();
                aadharLong = Long.parseLong(aadharString);
            } catch (NumberFormatException e) {
                // Handle the case where 'aadharString' is not a valid long
                e.printStackTrace();
            }

            // Insert customer information into the 'customers' table
            String customerSql = "INSERT INTO customers (cust_fname, cust_lname, cust_dob, cust_address, cust_gender, cust_cdate, cust_aadhar, cust_status, cust_luudate, cust_luuser, cust_user_id) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            // Assuming 'cust_cdate' is the current date
            // Assuming 'cust_status' is "Active"
            // Assuming 'cust_luuser' is 1 by default
            // Assuming 'cust_user_id' is retrieved from the session
            Long userId = (Long) session.getAttribute("userId");

            jdbcTemplate.update(customerSql, formData.getfName(), formData.getlName(), formData.getDob(),
                    formData.getAddress(), formData.getGender(), new Date(), aadharLong, "Active", new Date(), 1,
                    userId);
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exceptions here
        }

        try {
            // Get the current date
            Date currentDate = new Date();

            // Create a calendar instance and set it to the current date
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDate);

            // Add 30 days to the current date
            calendar.add(Calendar.DATE, 30);

            // Get the updated date
            Date updatedDate = calendar.getTime();

            // Create another calendar instance for the expiration date
            Calendar expirationCalendar = Calendar.getInstance();
            expirationCalendar.setTime(currentDate);

            // Add 1 year to the current date for expiration
            expirationCalendar.add(Calendar.YEAR, 1);

            // Get the expiration date
            Date expirationDate = expirationCalendar.getTime();

            // Insert insurance policy information into the 'insurancepolicies1' table
            String policySql = "INSERT INTO insurancepolicies1 (iplc_cust_id, iplc_insp_id, iplc_yrly_prem_amount, iplc_cdate, iplc_applicable_date, iplc_expdate, iplc_agnt_id, iplc_nom_insured, iplc_sum_assured, iplc_paymode_count) "
                    + "VALUES ((SELECT cust_id FROM customers ORDER BY cust_id DESC LIMIT 1), ?, ?, ?, ?, ?, 0, ?, ?, ?)";
            CID = jdbcTemplate.queryForObject("SELECT cust_id FROM customers ORDER BY cust_id DESC LIMIT 1", Long.class);
            jdbcTemplate.update(policySql, formData.getId(), formData.getPrice(), new Date(), updatedDate,
                    expirationDate, formData.getmName().length, formData.getSumassured(), formData.getPaymodecount());
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exceptions here
        }

        try {
            // Insert insurance policy coverage members into the 'insurancepolicycoveragemembers' table
            String memberSql = "INSERT INTO insurancepolicycoveragemembers (iplc_id, ipcm_membername, ipcm_relation, ipcm_dob, ipcm_gender, ipcm_healthhistory) "
                    + "VALUES ((SELECT iplc_id FROM insurancepolicies1 ORDER BY iplc_id DESC LIMIT 1), ?, ?, ?, ?, ?)";

            for (int i = 0; i < formData.getmName().length; i++) {
                jdbcTemplate.update(memberSql, formData.getmName()[i], formData.getRelationship()[i],
                        formData.getDob2()[i], formData.getGender1()[i], formData.getHealthHistory()[i]);
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exceptions here
        }
		return CID;
    }

    @Override
    public List<Faq> getGeneralFAQS() {
        return jdbcTemplate.query(SQL_GET_GFAQS, new FaqRowMapper());
    }

    @Override
    public List<Faq> getCoverageandBenefitsFAQS() {
        return jdbcTemplate.query(SQL_GET_CBFAQS, new FaqRowMapper());
    }
}
