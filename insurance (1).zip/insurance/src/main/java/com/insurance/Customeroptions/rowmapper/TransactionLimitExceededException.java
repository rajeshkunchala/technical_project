package com.insurance.Customeroptions.rowmapper;

public class TransactionLimitExceededException extends RuntimeException {
	public TransactionLimitExceededException(String message) {
		super(message);
	}
}
