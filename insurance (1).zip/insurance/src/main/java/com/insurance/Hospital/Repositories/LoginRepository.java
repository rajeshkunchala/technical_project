package com.insurance.Hospital.Repositories;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.insurance.Hospital.contracts.LoginDaoInterface;
import com.insurance.Hospital.contracts.LoginRepositoryInterface;
import com.insurance.Hospital.models.LoginClass;

@Repository
public class LoginRepository implements LoginRepositoryInterface {

	@Autowired
	LoginDaoInterface loginDaoInterface;

	@Override
	public int sendmail(String to_mail) {
		return loginDaoInterface.sendmail(to_mail);
	}

}
